//
// Created by marya on 4/23/2021.
//

#ifndef PS5_INFIX_H
#define PS5_INFIX_H
#include "stack.h"
void infix_to_rpn(char* expression, char *output, int* status);


#endif //PS5_INFIX_H
