//
// Created by marya on 4/22/2021.
//

#ifndef PS5_ERROR_H
#define PS5_ERROR_H

#define SUCCESS       0
#define NULLPTR       1
#define TOOMANY       2
#define TOOFEW        3
#define UNKNOWN       4

extern char errorMessages[][256];



#endif //PS5_ERROR_H
