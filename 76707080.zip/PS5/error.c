//
// Created by marya on 4/22/2021.
//

#include "error.h"
char errorMessages[][256] = {
        "Calculation successful.",
        "Nullptr error",
        "Too many operands",
        "Two few operands",
        "Unknown Operand"
};



