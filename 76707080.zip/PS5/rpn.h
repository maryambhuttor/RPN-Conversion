//
// Created by marya on 4/23/2021.
//

#ifndef PS5_RPN_H
#define PS5_RPN_H

#include "stack.h"
double evaluate(char* expression, int* status);




#endif //PS5_RPN_H
